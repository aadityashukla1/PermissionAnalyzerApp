# AppAnalyzer
This is an Android App which is based on my final year project(AppClassifier_ML)
